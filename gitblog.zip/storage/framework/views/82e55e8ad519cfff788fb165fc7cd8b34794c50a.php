   <div class="row">
        <div class="col-md-6 col-md-offset-3">
                <?php if(Session::has('success')): ?>
        <div class="alert alert-block alert-danger">
        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
        <?php echo e(Session::get('success')); ?>

        </div>
        <?php endif; ?>
        
        <p>Back to account :: <a href="<?php echo e(url('/profile')); ?>" class="btn btn-info">Back</a></p>   
                <h3>Create a post</h3>
    
                 <form role="form" method="POST" action="<?php echo e(route('admin.create-post')); ?>" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


    <div class="form-group <?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <label for="title">Title</label>
    <input type="text" name="title" class="form-control" id="title">
      <?php if($errors->has('title')): ?>
      <span class="help-block">
        <strong class="bg-white" style="color:black;"><?php echo e($errors->first('title')); ?></strong>
      </span>
      <?php endif; ?>
    </div>


    <div class="form-group <?php echo e($errors->has('content') ? ' has-error' : ''); ?>">
    <label for="title">Content</label>
    <input type="text" name="content" class="form-control" id="content">
      <?php if($errors->has('content')): ?>
      <span class="  help-block">
        <strong class="bg-white" style="color:black;"><?php echo e($errors->first('content')); ?></strong>
      </span>
      <?php endif; ?>
    </div>

     <div class="form-group">
                        <label for="post_image">Image Upload</label>
                        <input type="file" class="form-control" name="post_image">
                         <?php if($errors->has('post_image')): ?>
                        <span class="help-block">
        <strong class="bg-white" style="color:black;"><?php echo e($errors->first('post_image')); ?></strong>
      </span>
      <?php endif; ?>
      </div>

        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="checkbox">
    <label>
      <input type="checkbox" name="tags[]" value="<?php echo e($tag->id); ?>"> <?php echo e($tag->name); ?>

      </label>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
   
    <button type="submit" class="btn btn-success btn-lg"/>Publish</button>


  </form>

  





             </div>  
            </div>
