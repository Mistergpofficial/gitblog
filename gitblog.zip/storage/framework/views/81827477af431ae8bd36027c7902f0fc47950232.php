<?php $__env->startSection('content'); ?>

<div class="wrap">
    <div class="main">
        <div class="content">
            <div class="box1">
                 <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 class="post-title">
                 <a href="<?php echo e(url('posts') .'/'. $post->id); ?>" />
                 <?php echo e($post->title); ?>

                 </a>
                 </h3>
                    <span>By <?php echo e($post->user->full_name); ?>- <?php echo e($post->created_at->diffForHumans()); ?><span class="comments"><?php echo e($post->comments->count()); ?> Comments</span></span> 
                    <div class="blog-img">
                    <div class="view-back">
                        <span class="views" title="views">(566)</span>
                        <span class="likes" title="likes">(124)</span>
                        <span class="link" title="link">(24)</span>
                        <a href="single.html"> </a>
                    </div>
                    <img src="<?php echo e(url($post->image)); ?>" >
                </div>
                <div class="blog-data">
                    <p><?php echo e($post->content); ?></p>
                </div>

                    <span><a href="single.html">Continue reading >>></a></span>
                    <a href="<?php echo e(url('update-post', ['id' => $post->id])); ?>">Edit Post <a href="<?php echo e(url('delete-post') .'/'. $post->id); ?>">| Delete Post </a> </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                
            <div class="clear"></div>
        </div>

         <?php if(Session::has('success')): ?>
      <div class="alert alert-success">
        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
      <?php echo e(Session::get('success')); ?>

      </div>
   <?php endif; ?>

        <div class="comments-area">
                        <h3><img src="<?php echo e(url('images/r-blog.png')); ?>" title="comment">Leave a comment</h3>
                            <form action="<?php echo e(route('comments', ['id' => $post->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                                <p>
                                    <label>Name</label>
                                    <span>*</span>
                                    <input type="text" name="full_name" value="<?php echo e(Auth::user()->full_name); ?>">
                                </p>
                                <p>
                                    <label>Email</label>
                                    <span>*</span>
                                    <input type="email" name="email" value="<?php echo e(Auth::user()->email); ?>">
                                </p>
                                <p>
                                    <label>Subject</label>
                                    <span>*</span>
                                    <textarea name="body" class="form-control"></textarea>
                                </p>
                                <p>
                                    <input type="submit" value="Post">
                                </p>
                            </form>     
                        </div>

                        <div class="box comment">
        <h2><span>(<?php echo e($post->comments->count()); ?>)</span> Comment's</h2>

                    <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul class="list">
            <li>
                <div class="preview"></div>
                <div class="data">
                    <div class="title"><?php echo e($comment->user->full_name); ?>  <a href="#"> <?php echo e($comment->created_at->diffForHumans()); ?></a></div>
                    <p><?php echo e($comment->body); ?>.</p>
                </div>
                <div class="clear"></div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
      <div class="clear"></div>
    </div>


<!--Likes -->
<div class="box comment">
<h2><span>Like this post</span></h2>
 <p class="hidden"><?php echo e($currentUserLiked = false); ?></p>
<?php $__currentLoopData = $post->likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($like->user->id == $user->id): ?>
<p class="hidden"><?php echo e($currentUserLiked = true); ?></p>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if(!$currentUserLiked): ?>

<span class="likes"><?php echo e($post->likes->count()); ?>&nbsp;Likes</span><a href="<?php echo e(route('like', ['id' => $post->id])); ?>">&nbsp;<img src="<?php echo e(url('images/likes.png')); ?>" width="30">&nbsp;Like</a> <br>
 
 <?php else: ?>

<span class="unlikes"><?php echo e($post->likes->count()); ?>&nbsp;Likes</span><a href="<?php echo e(route('unlike', ['id' => $post->id])); ?>"><img src="<?php echo e(url('images/likes.png')); ?>" width="30">UnLike</a> <br>

<?php endif; ?>
</div>
<!--Like ends -->

        
                      
                    <div class="page_bottom">
                        <p>Back To : <a href="#">Top</a> |  <a href="#">Home</a></p>
                    </div>
            
</div>
<div class="sidebar">
<div class="sidebar_top">
    <h3>Blog Tags</h3>
    <?php echo $__env->make('layouts.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<br>

<div class="sidebar_top">
    <h3>Archives</h3>
    <?php echo $__env->make('layouts.sidebar2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
            
            <div class="latest_comments">
                    <h3>Latest Comments</h3>
                     <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="comments">
                    <p><span><?php echo e($comment->user->full_name); ?></span> commented on</p>
                     <h4><a href="#"><?php echo e($comment->post->title); ?></a></h4>
                     <p><?php echo e($comment->created_at->toFormattedDateString()); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>



            <div class="latest_photos">
                    <h3>Latest Photos</h3>
                    <ul>
                    
          
                        <li><a class="fancybox" href="images/img3.jpg" data-fancybox-group="gallery" title="Lorem ipsum dolor sit amet"><img src="<?php echo e(url($post->image)); ?>" width="50" height="50" /><span> </span></a></li>
            
                    </ul>
                </div>
        </div>
    <div class="clear"></div>
</div>
</div>
    

     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>