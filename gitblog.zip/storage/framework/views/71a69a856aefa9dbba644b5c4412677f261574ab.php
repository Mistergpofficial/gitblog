<?php $__env->startComponent('mail::message'); ?>
# Introduction

Thank you so much for registering with us at gitlinks blog, <?php echo e($user->full_name); ?>


<?php $__env->startComponent('mail::button', ['url' => 'https://google.com']); ?>
Return to Site
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
