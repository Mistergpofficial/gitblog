<?php $__env->startSection('content'); ?>



   <div class="login">
    <h1><a href="<?php echo e(url('/')); ?>">GITLINK BLOG </a></h1>
    <div class="login-bottom">
   
     <?php if(Session::has('success')): ?>
      <div class="alert alert-success">
        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
      <?php echo e(Session::get('success')); ?>

      </div>
   <?php endif; ?>
  
      <h2>User Registration</h2>
       <form class="form-login" action="<?php echo e(route('accounts.sign-up')); ?>" method="post" >
          <?php echo e(csrf_field()); ?>

          
      <div class="col-md-6">
       <input type="text" class="form-control" name="full_name" required value="<?php echo e(old('full_name')); ?>" autocomplete="off"
      autocorrect="off" placeholder="Full Name" />
      <?php if($errors->has('full_name')): ?>
      <span class="help-block">
        <strong class="bg-white"><?php echo e($errors->first('full_name')); ?></strong>
      </span>
      <?php endif; ?>
      <br>
    <input type="email" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autocomplete="off"
      autocorrect="off" placeholder="Email Address" />
        <?php if($errors->has('email')): ?>
      <span class="help-block">
      <strong class="bg-white"><?php echo e($errors->first('email')); ?></strong>
      </span>
      <?php endif; ?>
        <br>
      <input type="password" class="form-control" name="password" required autocomplete="off" autocorrect="off" placeholder="Password" />
         <span class="help-block">
      <strong class="bg-white"><?php echo e($errors->first('password')); ?></strong>
      </span>
      <br>

      <input type="password"  class="form-control" name="password_confirmation" required autocomplete="off" autocorrect="off" placeholder="Confirm Password" />
          <span class="help-block">
      <strong class="bg-white"><?php echo e($errors->first('password-confirm')); ?></strong>
      </span>
      <br>

       <input type="text"  class="form-control" name="phone_num" required value="<?php echo e(old('phone_num')); ?>" required placeholder="Phone Number "/>
     <br>
      

               
       

      
      
         
      </div>

      <div class="col-md-6 login-do">
        <label class="hvr-shutter-in-horizontal login-sub">
          <input type="submit" value="Register">
          </label>
          <p>Already have an account?</p>
        <a href="<?php echo e(route('accounts.sign-in')); ?>" class="hvr-shutter-in-horizontal">Login</a>
      </div>
      
      <div class="clearfix"> </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.acctbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>