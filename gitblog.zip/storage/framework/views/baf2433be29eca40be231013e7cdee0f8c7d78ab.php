 <div class="col-lg-10 col-lg-offset-1" style="background-color:white;">
    
        <br>
        <p>Back to account :: <a href="<?php echo e(url('/profile')); ?>" class="btn btn-info">Back</a></p>
          <?php if(Session::has('success')): ?>
      <div class="alert alert-success">
        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
        <?php echo e(Session::get('success')); ?>

      </div>
        <?php endif; ?>
                  
        <br/>
        <h1 class="">All Blog Users</h1>
        <h3></h3>
        <?php if($users->count() > 0): ?>
            <table class="table table-bordered">
                <thead>
                <tr> 
                    <th>User Id</th>
                    <th>Full Name</th>
                    <th>Phone Number</th>
                    <th>Email</th>
                    <th>Profile Photo</th>
                    <th>Action</th>
                  
                </tr>
                </thead>
                

                <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                        <th> <?php echo e($user->id); ?></th>
                        <th> <?php echo e($user->full_name); ?></th>
                        <th> <?php echo e($user->phone_num); ?></th>
                        <th> <?php echo e($user->email); ?></th>
                        <th><img src="<?php echo e($user->profile_pic); ?>" width="40" height="40" /></th>
                        <th>
                        <a href="<?php echo e(url('/delete-user') .'/'. $user->id); ?>">Delete User</a>
                        </th>
                 </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="alert alert-info"> No Blog Users found at this time...check back later</div>
        <?php endif; ?>
        <div class="row">
                    <div class="col-md-12 text-center">
                    <?php echo e($users->links()); ?>

                   </div>
                   </div>
 

    </div>