 <div class="sidebar_top_list">
     <ul>
       <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                <a href="<?php echo e(url('/posts/tags') .'/'. $tag); ?>">
                <?php echo e($tag); ?>

                </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
    </ul>
</div>

