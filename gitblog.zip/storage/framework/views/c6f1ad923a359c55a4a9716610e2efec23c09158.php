<?php $__env->startSection('content'); ?>



   <div class="login">
    <h1><a href="<?php echo e(url('/')); ?>">GITLINK BLOG </a></h1>
    <div class="login-bottom">
   
     <?php if(Session::has('danger')): ?>
      <div class="alert alert-danger">
        <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&#215;</button>
      <?php echo e(Session::get('danger')); ?>

      </div>
   <?php endif; ?>
  
      <h2>User Login</h2>
       <form class="form-login" action="<?php echo e(route('accounts.sign-in')); ?>" method="post" >
          <?php echo e(csrf_field()); ?>

          
      <div class="col-md-6">
        <label>
         Email<span class="req">*</span>
       </label>
    <input type="email" class="form-control" name="email" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required autocomplete="off"
      autocorrect="off"/>
        <?php if($errors->has('email')): ?>
      <span class="help-block">
      <strong class="bg-white"><?php echo e($errors->first('email')); ?></strong>
      </span>
      <?php endif; ?>

         <label>
         Password<span class="req">*</span>
       </label>
      <input type="password" class="form-control" name="password" required autocomplete="off" autocorrect="off"/>
         <span class="help-block">
      <strong class="bg-white"><?php echo e($errors->first('password')); ?></strong>
      </span>
      <br>

                <label>
                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                </label>

                 <label>
                 <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">Forgot Your Password?</a>
                </label>
       

      
      
         
      </div>

      <div class="col-md-6 login-do">
        <label class="hvr-shutter-in-horizontal login-sub">
          <input type="submit" value="login">
          </label>
          <p>Do not have an account?</p>
        <a href="<?php echo e(route('accounts.sign-up')); ?>" class="hvr-shutter-in-horizontal">Signup</a>
      </div>
      
      <div class="clearfix"> </div>
    </div>
  </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.acctbase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>