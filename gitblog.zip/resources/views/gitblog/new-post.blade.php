@extends('layouts.base1')
@section('content')
    @include('gitblog.new-post-template')
@endsection