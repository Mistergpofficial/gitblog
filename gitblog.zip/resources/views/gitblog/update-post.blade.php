@extends('layouts.base1')
@section('content')
    @include('gitblog.update-post-template')
@endsection