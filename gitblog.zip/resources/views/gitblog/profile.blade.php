@extends('layouts.base')
@section('content')
    @include('gitblog.profile-template')
@endsection