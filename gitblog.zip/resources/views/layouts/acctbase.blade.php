<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>GITLINK BLOG</title>
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style1.css" rel='stylesheet' type='text/css' />
<link href="css/font-awesome.css" rel="stylesheet"> 
</head>
<body>
@yield('content')
</body>
  <!---->
<div class="copy-right">
            <p> &copy; 2017 Gitlink Blog. All Rights Reserved | Design by <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>     </div>
    
<!---->
<!--scrolling js-->
<script src="js/jquery.min.js"> </script>
<script src="js/bootstrap.min.js"> </script>

  <script src="js/jquery.nicescroll.js"></script>
  <script src="js/scripts.js"></script>
  <!--//scrolling js-->
</body>
</html>

